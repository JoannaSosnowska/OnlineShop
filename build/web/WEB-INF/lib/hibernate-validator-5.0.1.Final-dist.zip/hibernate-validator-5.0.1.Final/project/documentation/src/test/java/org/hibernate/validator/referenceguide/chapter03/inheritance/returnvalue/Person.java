package org.hibernate.validator.referenceguide.chapter03.inheritance.returnvalue;

public class Person {
}
