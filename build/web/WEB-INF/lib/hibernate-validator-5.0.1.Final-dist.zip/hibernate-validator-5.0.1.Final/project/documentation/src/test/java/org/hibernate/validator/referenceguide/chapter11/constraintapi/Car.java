package org.hibernate.validator.referenceguide.chapter11.constraintapi;

public class Car {

	private String manufacturer;

	private String licensePlate;

	private Person driver;

	public void drive(int speedInMph) {
	}

	public Person getDriver() {
		return null;
	}
}
