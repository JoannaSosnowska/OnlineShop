package org.hibernate.validator.referenceguide.chapter03.inheritance.parallel;

public interface Car {

	public void drive(int speedInMph);
}
