package org.hibernate.validator.referenceguide.chapter03.returnvalue;

public class Customer {
}
